from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages # Import Messages Framework
from .forms import MahasiswaForm
from .models import Mahasiswa
from django.http import HttpResponse

# Fungsi Utama: Input dan Tampil Data
def input_mahasiswa(request):
    # 'pesan' sekarang hanya digunakan untuk pesan error form validation, bukan pesan sukses.

    if request.method == 'POST':
        form = MahasiswaForm(request.POST)
        if form.is_valid():
            # 1. Menyimpan data ke database
            Mahasiswa.objects.create(
                nama=form.cleaned_data['nama'],
                npm=form.cleaned_data['npm'],
                email=form.cleaned_data['email']
            )
            # 2. Menambahkan pesan sukses ke Messages Framework
            messages.success(request, "Data berhasil disimpan!")
            
            # 3. Menggunakan redirect ke halaman yang sama untuk mencegah form ganda
            return redirect('input_mahasiswa') 
        else:
            # Jika form tidak valid, pesan error akan ditampilkan oleh {{ form.as_p }}
            pass
    
    # Untuk GET request atau setelah POST gagal:
    form = MahasiswaForm()
    semua_mahasiswa = Mahasiswa.objects.all()

    return render(request, 'mahasiswa/input.html', {
        'form': form,
        # 'pesan' tidak lagi diperlukan di sini karena kita pakai Django Messages
        'semua_mahasiswa': semua_mahasiswa
    })


# Fungsi Edit Data Mahasiswa
def edit_mahasiswa(request, id_mahasiswa):
    mahasiswa = get_object_or_404(Mahasiswa, pk=id_mahasiswa)
    
    if request.method == 'POST':
        # Menggunakan instance=mahasiswa agar form tahu objek mana yang harus diupdate
        form = MahasiswaForm(request.POST, initial={'instance': mahasiswa}) 
        if form.is_valid():
            mahasiswa.nama = form.cleaned_data['nama']
            mahasiswa.npm = form.cleaned_data['npm']
            mahasiswa.email = form.cleaned_data['email']
            mahasiswa.save()
            
            messages.success(request, f"Data {mahasiswa.nama} berhasil diperbarui!")
            return redirect('input_mahasiswa')
    else:
        data_awal = {
            'nama': mahasiswa.nama,
            'npm': mahasiswa.npm,
            'email': mahasiswa.email
        }
        form = MahasiswaForm(initial=data_awal)

    return render(request, 'mahasiswa/edit.html', {
        'form': form,
        'mahasiswa': mahasiswa,
    })


# Fungsi Hapus Data Mahasiswa
def hapus_mahasiswa(request, id_mahasiswa):
    try:
        mahasiswa = Mahasiswa.objects.get(pk=id_mahasiswa)
        nama_mhs = mahasiswa.nama
        mahasiswa.delete()
        messages.success(request, f"Data {nama_mhs} berhasil dihapus.")
        return redirect('input_mahasiswa') 
    except Mahasiswa.DoesNotExist:
        messages.error(request, "Mahasiswa tidak ditemukan.")
        return redirect('input_mahasiswa')