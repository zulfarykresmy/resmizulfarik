from django.db import models

class Mahasiswa(models.Model):
    # Kolom untuk Nama (max_length=100)
    nama = models.CharField(max_length=100)
    # Kolom untuk NPM (max_length=20)
    npm = models.CharField(max_length=20)
    # Kolom untuk Email
    email = models.EmailField()

    # Representasi string untuk objek (Opsional tapi direkomendasikan)
    def __str__(self):
        return f"{self.nama} ({self.npm})"