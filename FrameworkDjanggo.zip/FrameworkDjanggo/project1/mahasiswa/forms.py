from django import forms

class MahasiswaForm(forms.Form):
    # Field untuk Nama (max_length=100)
    nama = forms.CharField(label='Nama', max_length=100)
    # Field untuk NPM (max_length=20)
    npm = forms.CharField(label='NPM', max_length=20)
    # Field untuk Email (standard email field)
    email = forms.EmailField(label='Email')