from django.urls import path
from . import views

urlpatterns = [
    path('input/', views.input_mahasiswa, name='input_mahasiswa'),
    path('edit/<int:id_mahasiswa>/', views.edit_mahasiswa, name='edit_mahasiswa'),
    path('hapus/<int:id_mahasiswa>/', views.hapus_mahasiswa, name='hapus_mahasiswa'),
]