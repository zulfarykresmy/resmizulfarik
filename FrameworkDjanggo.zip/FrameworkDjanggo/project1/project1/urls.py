from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    # Memasukkan semua URL dari 'mahasiswa.urls' di bawah prefix 'mahasiswa/'
    path('mahasiswa/', include('mahasiswa.urls')), 
]